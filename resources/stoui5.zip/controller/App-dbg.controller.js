sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("stoui5.controller.controller.App", {
        onInit() {
        }
      });
    }
  );
  